
# SSD Lab 1
## Roll no: 2024201007
- The zip file contains two .sh files:
    1) 2024201007_q1 which is the bash script for Q1
    2) 2024201007_q2 which is the bash script for Q2
------

- To execute the 1st script, use command: ./2024201007_q1.sh 

- To execute the 2nd script, use command: ./2024201007_q2.sh

------
- To give file permissions use command: 
    1) chmod +x 2024201007_q1.sh 
    2) chmod +x 2024201007_q2.sh

---------
- The output is visible on the terminal after the execution.

